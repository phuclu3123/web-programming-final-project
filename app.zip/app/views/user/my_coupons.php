<?php
$pageTitle = 'Mã của tôi - CouponHub';
$activePage = 'my_coupons';

// Dữ liệu mẫu bài gửi người dùng
$myCoupons = [
    [
        'code' => 'TIKIBOOK20',
        'store' => 'Tiki',
        'discount' => 'GIẢM 20K',
        'submitted_at' => '12/10/2026',
        'status' => 'PENDING',
        'status_text' => 'Chờ duyệt',
        'reason' => ''
    ],
    [
        'code' => 'GRABFOOD30',
        'store' => 'GrabFood',
        'discount' => 'GIẢM 30%',
        'submitted_at' => '10/10/2026',
        'status' => 'APPROVED',
        'status_text' => 'Đã duyệt',
        'reason' => ''
    ],
    [
        'code' => 'SHOPEE99K',
        'store' => 'Shopee',
        'discount' => 'GIẢM 99K',
        'submitted_at' => '05/10/2026',
        'status' => 'REJECTED',
        'status_text' => 'Bị từ chối',
        'reason' => 'Mã không tồn tại hoặc đã hết số lượng sử dụng tại thời điểm kiểm tra.'
    ]
];

require_once __DIR__ . '/layouts/header.php';
?>

<main class="category-page">
    <section class="category-heading">
        <div>
            <span class="category-eyebrow">COMMUNITY / QUẢN LÝ</span>
            <h1>Mã đóng góp của tôi</h1>
            <p>Xem danh sách mã bạn đã gửi và tiến độ kiểm duyệt từ quản trị viên.</p>
        </div>
    </section>

    <div class="my-coupons-list">
        <?php foreach ($myCoupons as $item): ?>
            <div class="my-coupon-card">
                <div class="my-coupon-header">
                    <div>
                        <strong><?= htmlspecialchars($item['code']) ?></strong>
                        <span class="store-tag">(<?= htmlspecialchars($item['store']) ?> - <?= htmlspecialchars($item['discount']) ?>)</span>
                    </div>
                    <span class="badge-status <?= strtolower($item['status']) ?>">
                        <?= htmlspecialchars($item['status_text']) ?>
                    </span>
                </div>
                
                <div class="my-coupon-meta">
                    <span>Ngày gửi: <?= $item['submitted_at'] ?></span>
                </div>

                <?php if ($item['status'] === 'REJECTED' && !empty($item['reason'])): ?>
                    <div class="rejection-box">
                        <strong>⚠️ Lý do Admin từ chối:</strong>
                        <p><?= htmlspecialchars($item['reason']) ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>