<?php
$pageTitle = 'CouponHub - Săn mã giảm giá';
$activePage = 'home';

require_once __DIR__ . '/data/coupons.php';

// Lấy TOP 3 danh mục nổi bật và danh sách coupon công khai
$topCategories = featuredCategories();
$coupons = publicCoupons();
$storeLogos = storeLogos();

require_once __DIR__ . '/layouts/header.php';
?>

<!-- HERO BANNER (ĐÃ BỎ THANH TÌM KIẾM TRÙNG LẶP) -->
<section class="hero">
    <div class="hero-content">
        <span class="hero-label">COUPONHUB · MUA SẮM THÔNG MINH</span>

        <h1>Săn mã giảm giá.<br><span>Tiết kiệm mỗi ngày.</span></h1>

        <p>Khám phá ưu đãi và mã giảm giá từ các cửa hàng yêu thích của bạn.</p>

        <!-- Nút chuyển hướng thay thế cho thanh tìm kiếm bị trùng -->
        <div class="hero-cta" style="margin-top: 24px;">
            <a href="/app/views/user/categories.php" class="detail-primary-button" style="padding: 12px 24px; font-size: 14px; border-radius: 10px;">
                Khám phá ưu đãi ngay ↗
            </a>
        </div>

        <div class="hero-note" style="margin-top: 24px;">
            <span>✓</span> Dễ dàng tìm kiếm trên Header
            <span>✓</span> Đa dạng danh mục
            <span>✓</span> Tiết kiệm chi tiêu
        </div>
    </div>

    <div class="hero-decoration">
        <div class="hero-ticket">
            <span class="ticket-small">ƯU ĐÃI ĐẶC BIỆT</span>
            <strong>30%</strong>
            <span>OFF</span>
            <div class="ticket-line"></div>
            <span class="ticket-bottom">SAVE MORE TODAY</span>
        </div>
        <div class="floating-tag">🎁 Ưu đãi hấp dẫn</div>
    </div>
</section>

<!-- TOP 3 DANH MỤC NỔI BẬT -->
<section class="featured-categories" id="categories">
    <div class="featured-heading">
        <div>
            <span class="featured-eyebrow">FIND YOUR NEXT DEAL</span>
            <h2>Danh mục nổi bật<span>.</span></h2>
            <p>Khám phá ưu đãi dành riêng cho những điều bạn yêu thích.</p>
        </div>

        <a href="/app/views/user/categories.php" class="featured-view-all">
            Xem tất cả <span>↗</span>
        </a>
    </div>

    <div class="category-top3-grid">
        <?php foreach ($topCategories as $index => $cat): ?>
            <a 
                href="/app/views/user/categories.php?category=<?= urlencode($cat['name']) ?>" 
                class="top3-card <?= $index === 0 ? 'top3-featured-main' : 'top3-card-sub' ?>"
            >
                <img class="top3-image" src="<?= htmlspecialchars($cat['image']) ?>" alt="<?= htmlspecialchars($cat['name']) ?>" loading="lazy">
                <div class="top3-overlay"></div>

                <span class="top3-number"><?= htmlspecialchars($cat['number']) ?></span>

                <div class="top3-content">
                    <span class="top3-kicker">CATEGORY / <?= htmlspecialchars($cat['number']) ?></span>
                    <h3><?= htmlspecialchars($cat['name']) ?></h3>
                    <p><?= htmlspecialchars($cat['subtitle']) ?></p>
                    <span class="top3-link">Khám phá ngay ↗</span>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- MÃ GIẢM GIÁ NỔI BẬT -->
<section class="coupon-section" id="coupons">
    <div class="section-heading">
        <div>
            <span class="section-label">DÀNH CHO BẠN</span>
            <h2>Mã giảm giá nổi bật</h2>
            <p>Tham khảo các ưu đãi được giới thiệu.</p>
        </div>
    </div>

    <div class="coupon-grid">
        <?php foreach ($coupons as $coupon): ?>
            <article 
                class="coupon-card" 
                onclick="window.location.href='/app/views/user/coupon_detail.php?code=<?= urlencode($coupon['code']) ?>'" 
                style="cursor: pointer;"
                data-coupon-code="<?= htmlspecialchars($coupon['code']) ?>"
            >
                <div class="coupon-card-top">
                    <div class="store-avatar">
                        <?php if (isset($storeLogos[$coupon['store']])): ?>
                            <img src="<?= htmlspecialchars($storeLogos[$coupon['store']]) ?>" alt="<?= htmlspecialchars($coupon['store']) ?>">
                        <?php else: ?>
                            <span class="highlands-logo">H</span>
                        <?php endif; ?>
                    </div>

                    <div class="store-info">
                        <h3><?= htmlspecialchars($coupon['store']) ?></h3>
                        <span><?= htmlspecialchars($coupon['category']) ?></span>
                    </div>

                    <button 
                        type="button" 
                        class="favorite-toggle-btn" 
                        data-favorite-code="<?= htmlspecialchars($coupon['code']) ?>"
                        onclick="event.stopPropagation();"
                    >
                        ❤️ <span class="fav-text">Yêu thích</span>
                    </button>
                </div>

                <div class="coupon-discount"><?= htmlspecialchars($coupon['discount']) ?></div>
                <h4><?= htmlspecialchars($coupon['title']) ?></h4>
                <p class="coupon-description"><?= htmlspecialchars($coupon['description']) ?></p>

                <div class="coupon-card-bottom">
                    <div class="coupon-code">
                        <span>MÃ:</span>
                        <strong><?= htmlspecialchars($coupon['code']) ?></strong>
                    </div>

                    <button 
                        type="button" 
                        class="copy-button" 
                        onclick="event.stopPropagation(); copyCoupon(this, '<?= htmlspecialchars($coupon['code']) ?>')"
                    >
                        Sao chép
                    </button>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>