<?php
$pageTitle = 'Chi tiết chiến dịch - CouponHub';
$activePage = 'campaigns';

require_once __DIR__ . '/data/coupons.php';

$campaignId = $_GET['id'] ?? 'sale-hang-thang';
$coupons = publicCoupons();

require_once __DIR__ . '/layouts/header.php';
?>

<main class="coupon-detail-page">
    <div class="campaign-hero">
        <span class="detail-eyebrow">CHIẾN DỊCH KHUYẾN MÃI</span>
        <h1>Siêu Sale Giữa Tháng - Giảm 50%</h1>
        <p>Hạn sử dụng chiến dịch: <strong>10/10/2026 - 20/10/2026</strong></p>
        <div class="campaign-timer">
            Thời hạn còn lại: <strong>05 ngày 14 giờ 20 phút</strong>
        </div>
    </div>

    <section class="category-results" style="margin-top: 32px;">
        <div class="category-section-heading">
            <div>
                <h2>Mã giảm giá áp dụng trong chiến dịch</h2>
                <p><?= count($coupons) ?> mã sẵn sàng sử dụng</p>
            </div>
        </div>

        <div class="category-coupon-list">
            <?php foreach ($coupons as $coupon): ?>
                <article class="category-coupon-card">
                    <div class="category-coupon-top">
                        <span class="category-store-name"><?= htmlspecialchars($coupon['store']) ?></span>
                        <span class="category-status"><?= htmlspecialchars($coupon['status']) ?></span>
                    </div>

                    <span class="category-coupon-discount"><?= htmlspecialchars($coupon['discount']) ?></span>
                    <h3><?= htmlspecialchars($coupon['title']) ?></h3>

                    <div class="category-coupon-bottom">
                        <span>Hạn dùng: <?= date('d/m/Y', strtotime($coupon['expiry'])) ?></span>
                        <a href="/app/views/user/coupon_detail.php?code=<?= urlencode($coupon['code']) ?>" class="category-view-button">
                            Lấy mã ngay
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>