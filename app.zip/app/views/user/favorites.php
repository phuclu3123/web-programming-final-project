<?php
$pageTitle = 'Mã giảm giá yêu thích - CouponHub';
$activePage = 'favorites';

require_once __DIR__ . '/data/coupons.php';
$coupons = publicCoupons();

require_once __DIR__ . '/layouts/header.php';
?>

<main class="category-page">
    <section class="category-heading">
        <div>
            <span class="category-eyebrow">TƯƠNG TÁC / LƯU TRỮ</span>
            <h1>Mã đã yêu thích</h1>
            <p>Các coupon bạn đã lưu để nhanh chóng áp dụng khi thanh toán.</p>
        </div>
    </section>

    <!-- Danh sách mã (Khớp data-coupon-code với JavaScript) -->
    <div class="category-coupon-list" id="favoriteCouponList">
        <?php foreach ($coupons as $coupon): ?>
            <article 
                class="category-coupon-card" 
                id="coupon-card-<?= htmlspecialchars($coupon['code']) ?>"
                data-coupon-code="<?= htmlspecialchars($coupon['code']) ?>"
            >
                <div class="category-coupon-top">
                    <span class="category-store-name">
                        <?= htmlspecialchars($coupon['store']) ?>
                    </span>

                    <!-- Nút Bỏ Yêu thích -->
                    <button 
                        type="button" 
                        class="favorite-toggle-btn active" 
                        data-favorite-code="<?= htmlspecialchars($coupon['code']) ?>"
                    >
                        ❤️ <span class="fav-text">Đã lưu</span>
                    </button>
                </div>

                <span class="category-coupon-discount">
                    <?= htmlspecialchars($coupon['discount']) ?>
                </span>

                <h3><?= htmlspecialchars($coupon['title']) ?></h3>

                <div class="category-coupon-bottom">
                    <span>Hạn dùng: <?= date('d/m/Y', strtotime($coupon['expiry'])) ?></span>

                    <a 
                        href="/app/views/user/coupon_detail.php?code=<?= urlencode($coupon['code']) ?>" 
                        class="category-view-button"
                    >
                        Chi tiết
                    </a>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <!-- Khối hiển thị khi chưa thả tim mã nào hoặc đã xóa hết -->
    <div class="category-empty" id="emptyFavoriteNotice" style="display: none;">
        <h3>Chưa có mã yêu thích nào</h3>
        <p>Khám phá và bấm thả tim ❤️ các mã giảm giá hấp dẫn để lưu lại nhé!</p>

        <a href="/app/views/user/categories.php" class="category-view-button" style="margin-top: 12px; display: inline-block;">
            Khám phá ưu đãi ngay
        </a>
    </div>
</main>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>