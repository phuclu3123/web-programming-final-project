<?php
$pageTitle = 'Chiến dịch khuyến mãi - CouponHub';
$activePage = 'campaigns';

require_once __DIR__ . '/data/coupons.php';

// Giả lập danh sách chiến dịch
$campaigns = [
    [
        'id' => 'sale-hang-thang',
        'title' => 'Siêu Sale Giữa Tháng - Giảm 50%',
        'description' => 'Hàng ngàn mã giảm giá độc quyền từ Shopee, Lazada, Tiki bùng nổ!',
        'badge' => 'Đang diễn ra',
        'start_date' => '10/10/2026',
        'end_date' => '20/10/2026',
        'banner' => 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80',
        'status' => 'active'
    ],
    [
        'id' => 'food-fest',
        'title' => 'Lễ Hội Ẩm Thực - Đồng Giá 1K',
        'description' => 'Tập hợp mã freeship và giảm 20% - 50% cho Highlands Coffee, ShopeeFood, GrabFood.',
        'badge' => 'Sắp kết thúc',
        'start_date' => '01/10/2026',
        'end_date' => '16/10/2026',
        'banner' => 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
        'status' => 'expiring'
    ],
    [
        'id' => 'tech-week',
        'title' => 'Tuần Lễ Công Nghệ & Phần Mềm',
        'description' => 'Săn voucher giảm đến 2.000.000đ khi mua laptop, phụ kiện và phần mềm bản quyền.',
        'badge' => 'Sắp diễn ra',
        'start_date' => '01/11/2026',
        'end_date' => '10/11/2026',
        'banner' => 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80',
        'status' => 'upcoming'
    ]
];

require_once __DIR__ . '/layouts/header.php';
?>

<div class="category-page">
    <section class="category-heading">
        <div>
            <span class="category-eyebrow">COUPONHUB / CAMPAIGN</span>
            <h1>Chiến dịch HOT</h1>
            <p>Tổng hợp các sự kiện khuyến mãi và đợt giảm giá lớn nhất trong tháng.</p>
        </div>
    </section>

    <div class="campaign-grid">
        <?php foreach ($campaigns as $camp): ?>
            <article class="campaign-card">
                <div class="campaign-banner">
                    <img src="<?= htmlspecialchars($camp['banner']) ?>" alt="<?= htmlspecialchars($camp['title']) ?>">
                    <span class="campaign-badge <?= $camp['status'] ?>">
                        <?= htmlspecialchars($camp['badge']) ?>
                    </span>
                </div>
                <div class="campaign-body">
                    <span class="campaign-time">⏰ <?= $camp['start_date'] ?> - <?= $camp['end_date'] ?></span>
                    <h3><?= htmlspecialchars($camp['title']) ?></h3>
                    <p><?= htmlspecialchars($camp['description']) ?></p>
                    
                    <a href="/app/views/user/campaign_detail.php?id=<?= urlencode($camp['id']) ?>" class="category-view-button">
                        Khám phá ưu đãi
                    </a>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>