/* =========================================
   COUPONHUB - USER INTERACTIONS (JS)
========================================= */

document.addEventListener('DOMContentLoaded', function () {
    initFavorites();
    initMobileMenu();
    initAuthModal();
    initLiveSearch();
});

/* ===== 1. QUẢN LÝ YÊU THÍCH (LOCALSTORAGE) ===== */

function getFavorites() {
    return JSON.parse(localStorage.getItem('couponhub_favorites') || '[]');
}

function saveFavorites(favs) {
    localStorage.setItem('couponhub_favorites', JSON.stringify(favs));
}

function initFavorites() {
    var favs = getFavorites();

    // Cập nhật trạng thái hiển thị của tất cả nút Yêu thích trên trang
    document.querySelectorAll('[data-favorite-code]').forEach(function (btn) {
        var code = btn.getAttribute('data-favorite-code');
        if (favs.includes(code)) {
            btn.classList.add('active');
            if (btn.querySelector('.fav-text')) {
                btn.querySelector('.fav-text').textContent = 'Đã lưu';
            }
        }

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            toggleFavorite(code, btn);
        });
    });

    // Nếu đang ở trang favorites.php, render danh sách mã đã lưu từ localStorage
    if (document.getElementById('favoriteCouponList')) {
        renderFavoritesPage();
    }
}

function toggleFavorite(code, btnElement) {
    var favs = getFavorites();
    var index = favs.indexOf(code);

    if (index === -1) {
        favs.push(code);
        if (btnElement) {
            btnElement.classList.add('active');
            if (btnElement.querySelector('.fav-text')) {
                btnElement.querySelector('.fav-text').textContent = 'Đã lưu';
            }
        }
    } else {
        favs.splice(index, 1);
        if (btnElement) {
            btnElement.classList.remove('active');
            if (btnElement.querySelector('.fav-text')) {
                btnElement.querySelector('.fav-text').textContent = 'Yêu thích';
            }
        }
    }

    saveFavorites(favs);

    // Xóa thẻ tương ứng nếu đang ở trang Yêu thích
    var card = document.getElementById('coupon-card-' + code);
    if (card && document.getElementById('favoriteCouponList')) {
        card.style.transition = 'all 0.3s ease';
        card.style.opacity = '0';
        card.style.transform = 'scale(0.9)';
        setTimeout(function () {
            card.remove();
            checkEmptyFavorites();
        }, 300);
    }
}

function checkEmptyFavorites() {
    var list = document.getElementById('favoriteCouponList');
    if (!list) return;

    var remaining = list.querySelectorAll('.category-coupon-card');
    var emptyNotice = document.getElementById('emptyFavoriteNotice');

    if (remaining.length === 0 && emptyNotice) {
        emptyNotice.style.display = 'block';
    }
}

function renderFavoritesPage() {
    var favs = getFavorites();
    var list = document.getElementById('favoriteCouponList');
    if (!list) return;

    var cards = list.querySelectorAll('.category-coupon-card');
    var count = 0;

    cards.forEach(function (card) {
        var code = card.getAttribute('data-coupon-code');
        if (!favs.includes(code)) {
            card.remove();
        } else {
            count++;
        }
    });

    if (count === 0) {
        checkEmptyFavorites();
    }
}

/* ===== 2. MOBILE MENU ===== */

function initMobileMenu() {
    var toggleBtn = document.getElementById('mobileMenuToggle');
    var nav = document.getElementById('mainNav');

    if (toggleBtn && nav) {
        toggleBtn.addEventListener('click', function () {
            nav.classList.toggle('open');
            toggleBtn.classList.toggle('active');
        });
    }
}

/* ===== 3. MODAL ĐĂNG NHẬP / ĐĂNG KÝ ===== */

function initAuthModal() {
    var openBtns = document.querySelectorAll('.open-auth-modal');
    var modal = document.getElementById('authModal');
    var closeBtn = document.getElementById('closeAuthModal');
    var tabBtns = document.querySelectorAll('.auth-tab-btn');

    openBtns.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            if (modal) modal.style.display = 'flex';
        });
    });

    if (closeBtn && modal) {
        closeBtn.addEventListener('click', function () {
            modal.style.display = 'none';
        });

        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    }

    tabBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            tabBtns.forEach(function (b) { b.classList.remove('active'); });
            btn.classList.add('active');

            var target = btn.getAttribute('data-target');
            document.querySelectorAll('.auth-form-content').forEach(function (f) {
                f.style.display = 'none';
            });
            var targetForm = document.getElementById(target);
            if (targetForm) targetForm.style.display = 'block';
        });
    });
}


/* ===== 4. TÌM KIẾM TỨC THÌ (LIVE SEARCH HEADER) ===== */

function initLiveSearch() {
    var input = document.getElementById('headerSearchInput');
    var suggestionsBox = document.getElementById('searchSuggestions');
    var coupons = window.ALL_COUPONS || [];

    if (!input || !suggestionsBox) return;

    input.addEventListener('input', function () {
        var query = this.value.trim().toLowerCase();

        if (query.length === 0) {
            suggestionsBox.innerHTML = '';
            suggestionsBox.classList.remove('active');
            return;
        }

        // Lọc các coupon khớp với từ khóa
        var matches = coupons.filter(function (item) {
            return item.store.toLowerCase().includes(query) ||
                   item.title.toLowerCase().includes(query) ||
                   item.code.toLowerCase().includes(query) ||
                   item.category.toLowerCase().includes(query) ||
                   item.discount.toLowerCase().includes(query);
        });

        if (matches.length === 0) {
            suggestionsBox.innerHTML = '<div class="suggestion-empty">Không tìm thấy mã nào phù hợp</div>';
            suggestionsBox.classList.add('active');
            return;
        }

        // Render tối đa 5 kết quả gợi ý
        var html = '';
        matches.slice(0, 5).forEach(function (item) {
            html += `
                <a href="/app/views/user/coupon_detail.php?code=${encodeURIComponent(item.code)}" class="suggestion-item">
                    <div class="suggestion-info">
                        <span class="suggestion-store">${escapeHtml(item.store)} · <strong class="suggestion-code">${escapeHtml(item.code)}</strong></span>
                        <span class="suggestion-title">${escapeHtml(item.title)}</span>
                    </div>
                    <span class="suggestion-discount">${escapeHtml(item.discount)}</span>
                </a>
            `;
        });

        html += `
            <a href="/app/views/user/search.php?q=${encodeURIComponent(query)}" class="suggestion-more">
                Xem tất cả ${matches.length} kết quả cho "${escapeHtml(query)}" ↗
            </a>
        `;

        suggestionsBox.innerHTML = html;
        suggestionsBox.classList.add('active');
    });

    // An dropdown khi click ra ngoài
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.header-search')) {
            suggestionsBox.classList.remove('active');
        }
    });

    input.addEventListener('focus', function () {
        if (this.value.trim().length > 0) {
            suggestionsBox.classList.add('active');
        }
    });
}

function escapeHtml(text) {
    var div = document.createElement('div');
    div.innerText = text;
    return div.innerHTML;
}